I started by animating the character kneeling to pet the creature in Maya, then I exported it to an FBX file and imported it into 
unity. After importing the file into unity I set up the animation controller with two states, at this point I realized that I 
needed a second animation to make the code work the way I wanted to so I made an extremely simple turn around using unity's built 
in animation tools. I set it up so that two UI buttons were used to set and reset the triggers on the animation controller to 
change between the animations. The animation controller is set up with transitions between the two animation states with the 
triggers being the condition of the transition. I ran into the issue with the animation not importing properly so the system was 
working properly and starting the animation, but the animation wasn't doing anything. I went back to maya and reexported the 
animation and that fixed most of it. The animation done with the IK handles on the arms and legs aren't importing into unity at 
all, but this lab is to focus on setting up animation controllers and I have made working controllers, and imported animations in 
past projects, as well as my main senior project game, so I decided to move on. I also somehow managed to break like seven packages 
in unity, I don't know how I managed to break them, I don't know how I fixed it. I turned it off and on again and it fixed itself.